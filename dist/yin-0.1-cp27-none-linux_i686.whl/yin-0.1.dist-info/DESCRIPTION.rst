A wrapper to the Yin algorithm, a well-established autocorrelation 
based pitch algorith.

